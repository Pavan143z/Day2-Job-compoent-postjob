import React, { Component } from 'react';

import{BrowserRouter as Router,Route,Link,Switch} from 'react-router-dom';
import Navbar from './components/Navbar'
import Home from './components/Home'
import Login from './components/Login'
import Register from './components/Register'
import Profile from './components/Profile'
import PostJob from './components/postjob'
import ManageJobs from './components/managejobs';
class App extends Component {
  render () {
    return (
     
       
      <Router>
   
      <div>
        
        <Navbar/>
        <div className="container">
        <Switch>
        <Route exact path="/managejob" component={ManageJobs}/>
         <Route exact path="/postjob" component={PostJob}/>
        
       
        </Switch>
        
        </div>
      </div>
  
    </Router>
         
        //  {/* <Route exact path="/" component={Home} /> */}
        //   {/* <div className="container">
        //     <Route exact path="/register" component={Register} />
        //     <Route exact path="/login" component={Login} />
        //     <Route exact path="/profile" component={Profile} />
        //   </div> */}

       
      
    );
  }
}



export default App;
